<?php

namespace App\Http\Middleware;

use Closure;
use App\User;

class RoleAdmin
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

        if($request->token == null){
            return response()->json([
                'message' => 'authorized user'
            ],401);
        }

        if(!$request->token == $user = user::where('token',$request->token)->first()){
            return response()->json([
                'message' => 'authorized user'
            ],401);
        }

        if($user->role == 'admin'){
            return $next($request);
        }

        

        return response()->json([
            'message' => 'authorized user'
        ],401);
    }
}
