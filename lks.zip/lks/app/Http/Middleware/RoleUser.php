<?php

namespace App\Http\Middleware;

use Closure;

use App\User;

class RoleUser
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        //$request->get('token');

        if($request->token == null){
            return response()->json([
                'message' => 'unauthorized user'
            ],401);
        }

        if(!$request->token == $user = user::where('token',$request->token)->first()){
            return response()->json([
                'message' => 'unauthorized user'
            ],401);
        }

        if($user->role == 'user'){
            return $next($request);    
        }

        return response()->json([
            'message' => 'unauthorized user'
        ],401);

        //return $next($request);


    }
}
