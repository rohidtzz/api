<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\support\facades\Validator;
use App\Route;
use App\Schedule;
use App\Place;
use Auth;

class ScheduleController extends Controller
{




    public function insert(request $request)
    {
        $Validator = Validator::make($request->all(),[
            'type' => 'required',
            'line' => 'required',
            'from_place_id' => 'required',
            'to_place_id' => 'required',
            'departure_time' => 'required',
            'arrival_time' => 'required',
            'distance' => 'required',
            'speed' => 'required'
        ]);

        if($Validator->fails()){
            return response()->json([
                'message' => 'data cannot be prossed',
                'error' => $Validator->errors()
            ],400);

        } else {

            $from_place_id = place::where('id',$request->from_place_id)->first();
            $to_place_id = place::where('id',$request->to_place_id)->first();

            if(!$from_place_id || !$to_place_id){
                return response()
                ->json(
                    ["messages"=> "Data cannot be processed"],
                    422
                );
            }


            $type = ['bus','train'];
            if(!in_array($request->type,$type)){
                return response()
                ->json(
                    ["messages"=> "Data cannot be processed"],
                    422
                );
            }

            schedule::create([
                'type' => $request->type,
                'line' => $request->line,
                'from_place' => $request->from_place_id,
                'to_place' => $request->to_place_id,
                'departure_time' => $request->departure_time,
                'arrival_time' => $request->arrival_time,
                'distance' => $request->distance,
                'speed' => $request->speed,
            ]);

            return response()
                ->json(
                    ["messages"=> "create success"],
                    200
                );




            
        }
        

    }


    public function delete($id)
    {
        $scheduleget = schedule::where('id',$id)->delete();

        if($scheduleget){
            return response()->json([
                'message' => 'delete success'
            ],200);
        } else {
            return response()->json([
                'message' => 'data cannot be delete'
            ],422);
        }
    }
}
