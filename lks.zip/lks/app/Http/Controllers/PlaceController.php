<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Place;
use App\User;
use Illuminate\Support\Facades\Validator;

class PlaceController extends Controller
{
    public function all(request $request)
    {

        $all = Place::all();

        return $all;

    }

    public function find(request $request,$id)
    {
        
        $find = Place::find($id);

        return $find;

    }

    public function insert(request $request)
    {

        $Validator = Validator::make($request->all(),[
            'name' => 'required',
            'latitude' => 'required',
            'longitude' => 'required',
            'x' => 'required | integer',
            'y' => 'required | integer',
            'image' => 'required',
            'description' => 'required',
        ]);

        if($Validator->fails()){
            return response()->json([
                'message' => 'data cannot be processsed',
                'error' => $Validator->errors(),
            ],422);

        } else {

            place::create([
                'name' => $request->name,
                'latitude' => $request->latitude,
                'longitude' => $request->longitude,
                'x' => $request->x,
                'y' => $request->y,
                'image' => $request->image,
                'description' => $request->description,
            ]);

            return response()->json([
                'message' => 'create success'
            ],200);

        }

    }

    public function update(request $request,$id)
    {
        
        $Validator = Validator::make($request->all(),[
            'name' => 'required',
            'latitude' => 'required',
            'longitude' => 'required',
            'x' => 'required | integer',
            'y' => 'required | integer',
            'image' => 'required',
            'description' => 'required',
        ]);

        if($Validator->fails()){
            return response()->json([
                'message' => 'data cannot be updated'
            ],400);
        } else {



            $check = place::where('id',$id)
                    ->update([
                        'name' => $request->name,
                        'latitude' => $request->latitude,
                        'longitude' => $request->longitude,
                        'x' => $request->x,
                        'y' => $request->y,
                        'image' => $request->image,
                        'description' => $request->description,
                    ]);

            if($check){
                return response()->json([
                    'message' => 'update success'
                ],200);
            }

            return response()->json([
                'message' => 'id not found in database'
            ],400);

        }

    }

    public function delete(request $request,$id)
    {

        if(!$id >= place::find($id)){
            return response()->json([
                'message' => 'data cannot be delete'
            ],400);
        }

        $delete = place::find($id)->delete();


        if($delete){
            return response()->json([
                'message' => 'delete success'
            ],200);
        } else {
            
        }

    }
}