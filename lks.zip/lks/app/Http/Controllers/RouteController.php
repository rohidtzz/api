<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Place;
use App\Schedule;
use App\Route;
use Auth;
use Illuminate\support\facades\Validator;


class RouteController extends Controller
{
    public function index($from,$to,$time)
    {

        if($time == null){
            return response()->json([
                'message' => 'data tidak ditemuka'
            ],400);
        }

        $Check1 = place::where('id', $from);
        $Check2 = place::Where('id',$to);

        if(!$Check1 || !$Check2){
            return response()->json([
                'message' => 'data cannot be proseesd'
            ],400);
        }
        
        $ScheduleGet = Schedule::with(['fromPlace','toPlace'])
        ->where([
            'from_place' => $from,
            'to_place' => $to,
            'departure_time' => $time
        ])->get();

        return $ScheduleGet;

    }

    public function insert(request $request)
    {
        $Validator = Validator::make($request->all(),[
            'from_place_id' => 'required | integer',
            'to_place_id' => 'required | integer',
            'schedule_id' => 'required | integer'
        ]);

        if($Validator->fails()){
            return response()->json([
                'message' => 'data cannot be prosscesd',
                'error' => $Validator->errors()
            ],401);
        }

        $Check1 = Place::where('id',$request->from_place_id);
        $Check2 = place::where('id',$request->to_place_id);

        if(!$Check1 || !$Check2){
            return response()->json([
                'message' => 'data cannot be prosscesd',
            ],401);
        }

        $Schedule = json_decode($request['schedule_id']);
        if(!is_array($Schedule)){
            $request['schedule_id'] = "[".$request['schedule_id']."]";
        }

        route::create([
            'from_place_id' => $request->from_place_id,
            'to_place_id' => $request->to_place_id,
            'schedule_id' => $request->schedule_id,
        ]);

        return response()->json([
            'message' => 'create success'
        ],200);
            

            

        
    }
}
