<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Illuminate\support\facades\Validator;

class AuthController extends Controller
{
    
    public function create(request $request)
    {

        $Validator = Validator::make($request->all(),[
            'username' => 'required',
            'email' => 'required | email | unique:users,email',
            'password' => 'required | min:5 | max:20'
        ]);

        if($Validator->fails()){

            return response()->json([
                'status' => false,
                'message' => $Validator->errors()
            ],401);
            
        } else {

            user::create([
                'username' => $request->username,
                'email' => $request->email,
                'password' => bcrypt($request->password),
                'role' => 'user'
            ]);

            return response()->json([
                'status' => true,
                'message' => 'create success'
            ],200);

        }

    }

    public function login(request $request)
    {

        $user = user::where('username', $request->username)->first();

        if($user){
            
            $pass_check = password_verify(
                $request->password,
                $user->password
            );

            if($pass_check){

                $token = bcrypt('');
                user::where('username',$request->username)
                ->update([
                    'token' => $token
                ]);

                return response()->json([

                    'token' => $token,
                    'role' => $user->role

                ],200);

            } else {

                return response()->json([
                    'message' => 'invalid login'
                ],401);

            }


        } else {
            return response()->json([
                'message' => 'invalid login'
            ],401);
        }

        

    }

    public function logout(request $request)
    {
        
        $TokenGet = $request->get('token');

        if($TokenGet == null){
            return response()->json([
                'message' => 'unauthorized user'
            ],200);  
        }

        $user = user::where('token',$request->token)->first();

        if($user){

            user::where('username', $user->username)
            ->update([
                'token' => null
            ]);

            return response()->json([
                'message' => 'logout success'
            ],200);

        } else {

            return response()->json([
                'message' => 'unauthorized user'
            ],200);

        }


    }


}
