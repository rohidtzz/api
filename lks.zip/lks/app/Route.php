<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Route extends Model
{
    protected $table = 'routes';

    protected $fillable = [

        'from_place_id', 'to_place_id', 'schedule_id'
        
    ];
}

