<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Schedule extends Model
{
    protected $table = 'schedules';

    protected $fillable = [
        'type', 'line', 'from_place' , 'to_place', 'departure_time', 'arrival_time', 'distance', 'speed'
    ];

    public function fromPlace(){
        return $this->hasOne('App\Place', 'id','from_place');
    }
    
    public function toPlace(){
        return $this->hasOne('App\Place', 'id', 'to_place');
    }

}
