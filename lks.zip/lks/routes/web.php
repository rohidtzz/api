<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


route::post('v1/auth/register', 'AuthController@create');
route::post('v1/auth/login', 'AuthController@login');


route::middleware('user')->group(function(){
    //place
    route::get('v1/place','PlaceController@all');
    route::get('v1/place/{id}','PlaceController@find');

    //route
    route::post('v1/route/selection', 'RouteController@insert');
    route::get('v1/route/search/{from}/{to}/{time}', 'RouteController@index');

});

route::middleware('admin')->group(function(){
    //place
    route::post('v1/place','PlaceController@insert');
    route::post('v1/place/{id}', 'PlaceController@update');
    route::delete('v1/place/{id}', 'PlaceController@delete');

    //schedule
    route::post('v1/schedule','ScheduleController@insert');
    route::delete('v1/schedule/{id}', 'ScheduleController@delete');


});



route::get('v1/auth/logout', 'AuthController@logout');
